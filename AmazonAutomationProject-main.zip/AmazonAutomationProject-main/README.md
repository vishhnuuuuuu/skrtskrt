# AmazonAutomationProject
Conducting blackbox uat and functional testing on amazon website
